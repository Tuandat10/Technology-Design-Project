//Add event listeners when the document is fully loaded
document.addEventListener('DOMContentLoaded', function() {
    // Handle navigation to the Items page from the Dashboard
    var itemsButton = document.getElementById('items');
    if (itemsButton) {
        itemsButton.addEventListener('click', function() {
            window.location.href = 'items.html';  
        });
    }

     // Handle navigation to the sign in page from the sign up
     var itemsButton = document.getElementById('join');
     if (itemsButton) {
         itemsButton.addEventListener('click', function() {
             window.location.href = 'r, sign in.html';  
         });
     }

     // Handle navigation to the dashboard page from the sign in
     var itemsButton = document.getElementById('login');
     if (itemsButton) {
         itemsButton.addEventListener('click', function() {
             window.location.href = 'dashboard.html';  
         });
     }

    // Handle navigation to the items history page from the dashboard
    var itemsButton = document.getElementById('orderHistory');
    if (itemsButton) {
        itemsButton.addEventListener('click', function() {
            window.location.href = 'order history.html';  
        });
    }

    // Handle navigation to the new order, notification page
    var itemsButton = document.getElementById('newOrderNoti');
    if (itemsButton) {
        itemsButton.addEventListener('click', function() {
            window.location.href = 'new order, notification.html';  
        });
    }

    // Handle navigation to the order accept page from the new order, notification page
    var itemsButton = document.getElementById('order1');
    if (itemsButton) {
        itemsButton.addEventListener('click', function() {
            window.location.href = 'new order, accept.html';  
        });
    }

    // Handle navigation to the new order, after accept page 
    var itemsButton = document.getElementById('orderAccept');
    if (itemsButton) {
        itemsButton.addEventListener('click', function() {
            window.location.href = 'new order, after accept.html';  
        });
    }

    // Handle navigation to the preparing, order page, from the new order, after accept page
    var itemsButton = document.getElementById('orderPreparing');
    if (itemsButton) {
        itemsButton.addEventListener('click', function() {
            window.location.href = 'preparing, order.html';
        });
    }

     // Handle navigation to the ready page, from the ready button in preparing, order page
     var itemsButton = document.getElementById('ready');
     if (itemsButton) {
         itemsButton.addEventListener('click', function() {
             window.location.href = 'ready.html';  
         });
     }

     // Handle navigation to the r delivering, order delivering, from the ready page
     var itemsButton = document.getElementById('pickUp1');
     if (itemsButton) {
         itemsButton.addEventListener('click', function() {
             window.location.href = 'r delivering, order delivering.html';  
         });
     }

     // Handle navigation to the r delivering, order delivered from the r delivering, order delivering page
     var itemsButton = document.getElementById('delivering');
     if (itemsButton) {
         itemsButton.addEventListener('click', function() {
             window.location.href = 'r delivering, order delivered.html';  
         });
     }

     // Handle navigation to the r delivering, order done from the r delivering, order delivered page
     var itemsButton = document.getElementById('delivered');
     if (itemsButton) {
         itemsButton.addEventListener('click', function() {
             window.location.href = 'r delivering, done.html';  
         });
     }
    
     // Handle navigation to the scheduled order, detail from accept button in scheduled order, notification
     var itemsButton = document.getElementById('schAccept');
     if (itemsButton) {
         itemsButton.addEventListener('click', function() {
             window.location.href = 'scheduled order, detail.html';  
         });
     }

     // Handle navigation to the scheduled order, accepted from X button in scheduled order, detail
     var itemsButton = document.getElementById('schXmark');
     if (itemsButton) {
         itemsButton.addEventListener('click', function() {
             window.location.href = 'scheduled order, accepted.html';  
         });
     }

    // Handle navigation to the Dashboard 
    var homeButton = document.getElementById('home');
    if (homeButton) {
        homeButton.addEventListener('click', function() {
            window.location.href = 'dashboard.html';
        });
    }

   

});