//Add event listeners when the document is fully loaded
document.addEventListener('DOMContentLoaded', function() {
    // Handle navigation to the Items page from the Dashboard
    var itemsButton = document.getElementById('items');
    if (itemsButton) {
        itemsButton.addEventListener('click', function() {
            window.location.href = 'items.html';  // Correct the file name if necessary
        });
    }

    // Handle navigation to the Items history page from the Dashboard
    var itemsButton = document.getElementById('orderHistory');
    if (itemsButton) {
        itemsButton.addEventListener('click', function() {
            window.location.href = 'order history.html';  // Correct the file name if necessary
        });
    }

    var itemsButton = document.getElementById('newOrder');
    if (itemsButton) {
        itemsButton.addEventListener('click', function() {
            window.location.href = 'new order.html';  // Correct the file name if necessary
        });
    }

    // Handle navigation to the Dashboard from the Items page
    var homeButton = document.getElementById('home');
    if (homeButton) {
        homeButton.addEventListener('click', function() {
            window.location.href = 'dashboard.html';
        });
    }

    // Handling accept button click events
    const acceptButtons = document.querySelectorAll('.accept-button');
    acceptButtons.forEach(button => {
        button.addEventListener('click', function() {
            const orderElement = this.closest('.order');
            const orderDetails = {
                code: orderElement.querySelector('.order-code').textContent,
                time: orderElement.querySelector('.order-time').textContent,
                name: orderElement.querySelector('.order-name').textContent,
                total: orderElement.querySelector('.order-total').textContent,
                items: orderElement.querySelector('.order-items').textContent
            };
            moveToPreparing(orderDetails);
            updateCounters(-1, 1);
            orderElement.remove(); // Remove the order from the current page
        });
    });

    // Function to move the accepted order to preparing
    function moveToPreparing(orderDetails) {
        // Here you might make an AJAX call or similar to update the backend and reflect on the "preparing.html"
        console.log("Moving to preparing:", orderDetails);
    }

    // Function to update counters for new orders and preparing
    function updateCounters(newDelta, preparingDelta) {
        const newOrderCountElement = document.getElementById('new-order-count');
        const preparingCountElement = document.getElementById('preparing-count');

        if (newOrderCountElement) {
            let currentCount = parseInt(newOrderCountElement.textContent) || 0;
            newOrderCountElement.textContent = currentCount + newDelta;
        }

        if (preparingCountElement) {
            let currentCount = parseInt(preparingCountElement.textContent) || 0;
            preparingCountElement.textContent = currentCount + preparingDelta;
        }
    }


});