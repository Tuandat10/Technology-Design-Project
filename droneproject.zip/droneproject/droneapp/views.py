from django.shortcuts import render

def Home(request):
    return render(request,'Home.html')
def Restaurants(request):
    return render(request,"Restaurants.html")
def Cart(request):
    return render(request,"Cart.html")
def Profile(request):
    return render(request,"Profile.html")
def Menu(request):
    return render(request,"Menu.html")
# Create your views here.
