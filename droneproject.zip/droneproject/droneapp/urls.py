from django.urls import path
from . import views

urlpatterns = [
    path("", views.Home, name="Home"),
    path("Restaurants/",views.Restaurants,name="Restaurants"),
    path("Cart/",views.Cart,name="Cart"),
    path("Profile/",views.Profile, name="Profile"),
    path("Menu/",views.Menu, name="Menu")

]